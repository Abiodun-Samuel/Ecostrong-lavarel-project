<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Ecostrong Company</title>
</head>

<body>
    <h3> Subject: <?php echo e($details['subject']); ?> </h3>

    <p> <b>Name:</b> <?php echo e($details['name']); ?></p>
    <p> <b>Email:</b> <?php echo e($details['email']); ?> </p>
    <p> <b> Phone Number:</b> <?php echo e($details['phone']); ?> </p>
    <p> <b>Message:</b> <?php echo e($details['message']); ?> </p>

    <b> <a href="mailto:<?php echo e($details['email']); ?>"> Reply <?php echo e($details['name']); ?> </a> </b>


</body>

</html>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/emails/ContactMail.blade.php ENDPATH**/ ?>