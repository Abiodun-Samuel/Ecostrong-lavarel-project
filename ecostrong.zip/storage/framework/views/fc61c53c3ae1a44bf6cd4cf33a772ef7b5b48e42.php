 <!-- ======= Contact Section ======= -->
 <section id="contact-page" class="contact section-bg">
     <div class="container" data-aos="fade-up">
         <div class="section-title">
             <h2>Contact</h2>
             <p>
                 Magnam dolores commodi suscipit. Necessitatibus eius consequatur
                 ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam
                 quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.
                 Quia fugiat sit in iste officiis commodi quidem hic quas.
             </p>
         </div>

         <div class="row">
             <div class="col-lg-6">
                 <div class="info-box mb-4">
                     <i class="bx bx-map"></i>
                     <h3>Our Address</h3>
                     <p>A108 Adam Street, New York, NY 535022</p>
                 </div>
             </div>

             <div class="col-lg-3 col-md-6">
                 <div class="info-box mb-4">
                     <i class="bx bx-envelope"></i>
                     <h3>Email Us</h3>
                     <p>contact@example.com</p>
                 </div>
             </div>

             <div class="col-lg-3 col-md-6">
                 <div class="info-box mb-4">
                     <i class="bx bx-phone-call"></i>
                     <h3>Call Us</h3>
                     <p>+1 5589 55488 55</p>
                 </div>
             </div>
         </div>

         <div class="row">

             <div class="col-lg-6 col-md-6">
                 <div class="card hover-border">
                     <div class="card-body">
                         <h6 class="card-title">Lorem ipsum dolor sit amet.</h6>
                         <p class="card-text">
                             <hr>
                         <ul>
                             <li>
                                 <div><i class="fas fa-user-clock"></i></div> Working Hours: Mon - Fri: 9AM to 5PM, Sun:
                                 9AM to 1PM
                             </li>
                             <li>
                                 <div><i class="fas fa-map-marker-alt "></i></div>
                                 A108 Adam Street
                                 New York, NY 535022
                                 United States
                             </li>
                             <li>
                                 <a href="">
                                     <div> <i class="fas fa-phone-alt "></i></div> +1
                                     5589 55488 55
                                 </a>

                             </li>
                             <li>
                                 <a href="
                                       ">
                                     <div><i class="far fa-envelope"></i></div> info@example.com
                                 </a>

                             </li>

                         </ul>
                         <hr>
                         <div class="contact-icons">
                             <a href="#"><i class="fab fa-whatsapp"></i></a>
                             <a href=""><i class="fab fa-telegram-plane"></i></a>
                             <a href="#"><i class="fab fa-facebook"></i></a>
                             <a href="#"><i class="fab fa-twitter"></i></a>
                             <a href="#"><i class="fab fa-instagram"></i></a>
                             <a href="#"><i class="fab fa-linkedin"></i></a>
                         </div>
                         </p>

                     </div>
                 </div>
             </div>

             <div class=" col-lg-6 col-md-6">
                 <div class="card">
                     <div class="card-body">
                         <div class="contact">
                             <div class="form">
                                 <div id="sendmessage">
                                     Your message has been sent. Thank you!
                                 </div>
                                 <div id="errormessage"></div>
                                 <form action="" method="post" role="form" class="contactForm">

                                     <div class="form-row">
                                         <div class="form-group col-lg-6">
                                             <input type="text" name="name" class="form-control" id="name"
                                                 placeholder="Name" data-rule="minlen:4"
                                                 data-msg="Please enter at least 4 chars" />
                                             <div class="validation"></div>
                                         </div>
                                         <div class="form-group col-lg-6">
                                             <input type="number" class="form-control" name="phone" id="phone"
                                                 placeholder="Phone Number" data-rule="phone"
                                                 data-msg="Please enter a valid phone number" />
                                         </div>
                                         <div class="form-group col-lg-12">
                                             <input type="email" class="form-control" name="email" id="email"
                                                 placeholder="Your Email" data-rule="email"
                                                 data-msg="Please enter a valid email" />
                                             <div class="validation"></div>
                                         </div>

                                         <div class="form-group col-lg-12">
                                             <textarea class="form-control" name="message" rows="4" data-rule="required"
                                                 data-msg="Please write something for us"
                                                 placeholder="Message"></textarea>
                                             <div class="validation"></div>
                                         </div>
                                     </div>
                                     <div class="text-center">
                                         <button type="submit" title="Send Message">
                                             Send Message
                                         </button>
                                     </div>
                                 </form>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>

         </div>
     </div>
 </section>
 <!-- End Contact Section -->
<?php /**PATH C:\Users\abiod\Desktop\Web Development\PHP-Projects\ecostrong\resources\views/layouts/contact.blade.php ENDPATH**/ ?>