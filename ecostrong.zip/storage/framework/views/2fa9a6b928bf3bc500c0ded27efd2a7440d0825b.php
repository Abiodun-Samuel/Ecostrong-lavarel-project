

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.inner_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="service_page">
        <div class="container">
            <h3>
                General trading & Contract
            </h3>

            <p>
                At Ecostrong Company, we can be hired by client based on contract to design, analyze, process, develop and
                execute information, ideas, products, services or projects. We help to monitor and supervise any tasks
                contracted to us effectively and efficiently.
            </p>

            <p>
                We accept business offer from parties which is based on legally binding agreement as regarding buying and
                selling of goods and services. Also, we accept partnership deal with third parties on legal business.
            </p>

            <p>
                We carry on business contract general merchandise, building/construction services, sales and services of
                household items, interior/exterior services, agency services, communication services, installation of
                industrial/domestic materials and accessories and supplier of all kinds of consumables goods.
            </p>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abiod\Desktop\Web Development\PHP-Projects\ecostrong\resources\views/services/General Trading & Contract.blade.php ENDPATH**/ ?>