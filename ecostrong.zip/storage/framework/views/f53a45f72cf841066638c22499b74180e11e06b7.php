

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.inner_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="service_page">
        <div class="container">
            <h3>
                Real Estate and Properties Management
            </h3>
            <p>
                The best Investment you could ever venture into is real estate. We proffer solution in land properties and
                houses at affordable prices. At Ecostrong we sell, buy and also find buyers for land, buildings, gardens,
                farm land and properties.
                Ecostrong provides service for individuals that want to lease or want a lease of properties and buildings.
                Providing a serene, developed, conducive and well facilitated environment for clients is our objective. We

                also make our price affordable for all.
            </p>
            <p>
                You can buy, acquire, and invest in any of our land properties across Nigeria. We help individuals to pay
                comfortably within the space of 3-6 months.

            </p>
            <p>
                Due to constant development, the price of our land properties in Lagos, Ibadan, and in Abeokuta increases
                within a cycle of 6 months; this is a big opportunity for individuals to acquire and invest in real estate.
            </p>
        </div>
    </section>

    <?php echo $__env->make('layouts.cta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.property_temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.cta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/services/Real Estate & Properties Management.blade.php ENDPATH**/ ?>