<div id="inner-page">
    <div class="container">
        <div class="top-bar">
            <h4> <a href="<?php echo e(url('/')); ?>"> Home </a> | <?php echo e($innertitle); ?> </h4>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\abiod\Desktop\Web Development\PHP-Projects\ecostrong\resources\views/layouts/inner_header.blade.php ENDPATH**/ ?>