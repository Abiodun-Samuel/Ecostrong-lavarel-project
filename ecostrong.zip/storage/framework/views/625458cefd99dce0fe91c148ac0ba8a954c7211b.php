<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ecostrong Company</title>
</head>

<body>

    <h3> Application Form Submitted by <?php echo e($applicants['surname']); ?></h3>

    <p> <b>Name:</b> <?php echo e($applicants['surname']); ?> <?php echo e($applicants['othernames']); ?> </p>
    <p> <b>Email:</b> <?php echo e($applicants['email']); ?> </p>
    <p> <b> Phone Number:</b> <?php echo e($applicants['phone']); ?> </p>
    <p> <b>Address:</b> <?php echo e($applicants['address']); ?> </p>

    <b> <a href="mailto:<?php echo e($applicants['email']); ?>"> Reply <?php echo e($applicants['surname']); ?> </a> </b>

</body>

</html>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/emails/ApplicantsMail.blade.php ENDPATH**/ ?>