<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ecostrong Company</title>
</head>

<body>


    <h3> Registration Form Submitted by <?php echo e($formDetails['surname']); ?></h3>

    <p> <b>Name:</b> <?php echo e($formDetails['surname']); ?> <?php echo e($formDetails['othernames']); ?> </p>
    <p> <b>Email:</b> <?php echo e($formDetails['email']); ?> </p>
    <p> <b> Phone Number:</b> <?php echo e($formDetails['phone']); ?> </p>
    <p> <b>Address:</b> <?php echo e($formDetails['address']); ?> </p>

    <b> <a href="mailto:<?php echo e($formDetails['email']); ?>"> Reply <?php echo e($formDetails['surname']); ?> </a> </b>


</body>

</html>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/emails/FormMail.blade.php ENDPATH**/ ?>