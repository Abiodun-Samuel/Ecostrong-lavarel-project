 <section>
     <div class="row mt-3">
         <div class="col-lg-12">
             <div class="newsletter">
                 <h1> Newsletter</h1>
                 <p>The ladder of success is best climbed by stepping on the rungs of opportunities. Open up your
                     world of endless possibilities by joining our mailing list </p>
                 <div class="text">
                     <input type="text" placeholder="Enter Your Email" />
                     <button>
                         <i><svg width="2em" height="2em" viewBox="0 0 16 16">
                                 <path d="M6 8H1V6h5V4l3 3l-3 3zm10-8v13l-6 3v-3H4V9h1v3h5V3l4-2H5v4H4V0z" />
                             </svg></i>
                     </button>
                 </div>
             </div>
         </div>
     </div>
 </section>
<?php /**PATH C:\Users\abiod\Desktop\Web Development\PHP-Projects\ecostrong\resources\views/layouts/newsletter.blade.php ENDPATH**/ ?>