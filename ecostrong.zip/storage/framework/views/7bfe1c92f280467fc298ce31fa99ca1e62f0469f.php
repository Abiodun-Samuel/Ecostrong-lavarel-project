<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel Contact Form Example</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>

<body>
    <div class="container pt-5" style="max-width: 500px">

        <!-- Alert User -->
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <form action="" method="post" action="<?php echo e(route('contact.save')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" name="name" id="name">

                <!-- Show error -->
                <?php if($errors->has('name')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email" id="email">

                <!-- Show error -->
                <?php if($errors->has('email')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>                
            </div>

            <div class="form-group">
                <label>Phone</label>
                <input type="number" class="form-control" name="phone" id="phone">

                <!-- Show error -->
                <?php if($errors->has('phone')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>                                
            </div>

            <div class="form-group">
                <label>Subject</label>
                <input type="text" class="form-control" name="subject" id="subject">

                <!-- Show error -->
                <?php if($errors->has('subject')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('subject')); ?>

                    </div>
                <?php endif; ?>                 
            </div>

            <div class="form-group">
                <label>Message</label>
                <textarea class="form-control" name="message" id="message" rows="5"></textarea>

                <!-- Show error -->
                <?php if($errors->has('message')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first('message')); ?>

                    </div>
                <?php endif; ?>                    
            </div>

            <input type="submit" name="send" value="Send" class="btn btn-dark btn-block">
        </form>
    </div>
</body>

</html><?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/welcome.blade.php ENDPATH**/ ?>