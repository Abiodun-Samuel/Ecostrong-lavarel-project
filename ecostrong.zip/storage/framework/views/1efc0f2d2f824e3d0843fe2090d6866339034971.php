

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts/inner_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="forms">

        <div class="container">
            <div class="section-title">
                <P class="my-3 text-uppercase"> <b>Kindly Fill the Application form below appropriately </b> </P>
            </div>


            

            <div class="row my-5">
                <div class="col-lg-9 col-md-10">
                    <div class="form">


                        <?php if(Session::has('message_sent')): ?>

                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('message_sent')); ?>

                            </div>

                        <?php endif; ?>

                        <form action="<?php echo e(route('vacancy.submit')); ?> " enctype="multipart/form-data" method="POST"
                            role="form" class="contactForm">
                            <?php echo csrf_field(); ?>

                            <p> <small>* fields are required</small></p>

                            
                            <div class="form-row">

                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="surname">Surname<span>*</span></label>
                                    <input type="text" name="surname" class="form-control" id="surname" required
                                        placeholder="Surname" value="<?php echo e(old('surname')); ?>" />

                                    <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="othernames">Other Names<span>*</span></label>
                                    <input type="text" class="form-control" name="othernames" id="othernames" required
                                        placeholder="Other Names" value="<?php echo e(old('othernames')); ?>" />

                                    
                                    <?php $__errorArgs = ['othernames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            
                            <div class="form-row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="phone">Phone (Whatsapp)<span>*</span> </label>
                                    <input type="tel" class="form-control" id="phone" name="phone"
                                        placeholder="080 XXX XXXX XXX" value="<?php echo e(old('phone')); ?>" size="11" required>

                                    
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="email"> Email <span>*</span> </label>
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Enter Your Email" value="<?php echo e(old('email')); ?>" />



                                    
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            
                            <div class="form-row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="address"> Home Address <span>*</span> </label>
                                    <input type="text" class="form-control" name="address" id="address"
                                        placeholder="Home Address" value="<?php echo e(old('address')); ?>" />

                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>


                                
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="state">State<span>*</span> </label>

                                    <select name="state" id="state" class="form-control" required>
                                        <option value="" selected="selected">- Select -</option>
                                        <option value="Abia">Abia</option>
                                        <option value="Adamawa">Adamawa</option>
                                        <option value="AkwaIbom">AkwaIbom</option>
                                        <option value="Anambra">Anambra</option>
                                        <option value="Bauchi">Bauchi</option>
                                        <option value="Bayelsa">Bayelsa</option>
                                        <option value="Benue">Benue</option>
                                        <option value="Borno">Borno</option>
                                        <option value="Cross River">Cross River</option>
                                        <option value="Delta">Delta</option>
                                        <option value="Ebonyi">Ebonyi</option>
                                        <option value="Edo">Edo</option>
                                        <option value="Ekiti">Ekiti</option>
                                        <option value="Enugu">Enugu</option>
                                        <option value="FCT">FCT</option>
                                        <option value="Gombe">Gombe</option>
                                        <option value="Imo">Imo</option>
                                        <option value="Jigawa">Jigawa</option>
                                        <option value="Kaduna">Kaduna</option>
                                        <option value="Kano">Kano</option>
                                        <option value="Katsina">Katsina</option>
                                        <option value="Kebbi">Kebbi</option>
                                        <option value="Kogi">Kogi</option>
                                        <option value="Kwara">Kwara</option>
                                        <option value="Lagos">Lagos</option>
                                        <option value="Nasarawa">Nasarawa</option>
                                        <option value="Niger">Niger</option>
                                        <option value="Ogun">Ogun</option>
                                        <option value="Ondo">Ondo</option>
                                        <option value="Osun">Osun</option>
                                        <option value="Oyo">Oyo</option>
                                        <option value="Plateau">Plateau</option>
                                        <option value="Rivers">Rivers</option>
                                        <option value="Sokoto">Sokoto</option>
                                        <option value="Taraba">Taraba</option>
                                        <option value="Yobe">Yobe</option>
                                        <option value="Zamfara">Zamafara</option>
                                    </select>

                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>


                            
                            <div class="form-row">

                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="gender">GENDER: </label>
                                    <select id="gender" name="gender">
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="others">Others</option>
                                    </select>
                                </div>

                                
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="birthday">Date of Birth:</label>
                                    <input type="date" id="birthday" name="birthday">
                                </div>

                            </div>

                            
                            <div class="form-row">

                                <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                    <label for="cv">Upload your CV:<span>*</span> </label>
                                    <input type="file" id="cv" name="cv" accept="file/doc, file/pdf">
                                    <label for="cv"> <small> <em> <b>(pdf and doc file format, less than 2mb)</b> </em>
                                        </small></label>
                                    <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            
                            <div class="form-row">
                                <div class="col-lg-12">
                                    <input type="radio" id="confirm" name="confirm" value="confirm">
                                    <label>I hereby declare that all information disclosed are correct and
                                        valid.</label>

                                    
                                    <?php $__errorArgs = ['confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>



                            
                            <div class="text-center my-3">
                                <button type="submit" title="Send Message">
                                    Register
                                </button>

                                
                                <input class="mx-3" type="reset" value="Clear">
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/forms/vacancyForm.blade.php ENDPATH**/ ?>