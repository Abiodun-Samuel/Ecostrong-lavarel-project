

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts/inner_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="forms">

        <div class="container">
            <div class="section-title">
                <h2>SignUp Form </h2>
                <P class="my-3 text-uppercase"> Kindly Fill the Registration form below appropriately </P>
            </div>

            <div class="row my-5">
                <div class="col-lg-9 col-md-10">
                    <div class="form">

                        <?php if(Session::has('message_sent')): ?>

                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('message_sent')); ?>

                            </div>

                        <?php endif; ?>

                        <form action="<?php echo e(route('form.send')); ?> " enctype="application/x-www-form-urlencoded" method="POST"
                            role="form" class="contactForm">
                            <?php echo csrf_field(); ?>

                            
                            <div class="form-row  my-2">

                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="form">Select Form:<span>*</span> </label>
                                    <select id="form" name="form_type">
                                        <option>- Form -</option>
                                        <option value="General Trading & Contract">General Trading & Contract
                                        </option>
                                        <option value="Project Management">Project Management</option>
                                        <option value="Project & Investment Scheme">Project & Investment Scheme</option>
                                        <option value="Business Management & Consultancy">Business Management & Consultancy
                                        </option>
                                        <option value="Ecovest Investment and Training"> Ecovest Investment and Training
                                        </option>
                                    </select>

                                    <?php $__errorArgs = ['form_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            
                            <div class="form-row">

                                <div class="form-group col-lg-12">

                                    <label for="name"> Training Type:<span>*</span></label>
                                    <input type="radio" id="Regular" name="training_type" value="Regular">
                                    <label for="Regular"> Regular</label>
                                    <input type="radio" id="Advanced" name="training_type" value="Advanced">
                                    <label for="Advanced">Advanced</label>


                                    <?php $__errorArgs = ['training_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                            <hr>

                            
                            <div class="form-row">

                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="name">Surname<span>*</span></label>
                                    <input type="text" name="surname" class="form-control" id="name" minlength="3"
                                        maxlength="50" placeholder="Surname" value="<?php echo e(old('surname')); ?>" />


                                    <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="othernames">Other Names</label>
                                    <input type="text" class="form-control" name="othernames" id="othernames"
                                        placeholder="Other Names" value="<?php echo e(old('othernames')); ?>" />
                                </div>

                            </div>

                            
                            <div class="form-row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="phone">Phone (Whatsapp)<span>*</span> </label>
                                    <input type="tel" class="form-control" id="phone" name="phone"
                                        placeholder="080 XXX XXXX XXX" value="<?php echo e(old('phone')); ?>">


                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div>

                                
                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="email"> Email <span>*</span> </label>
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Enter Your Email" value="<?php echo e(old('email')); ?>" />


                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for="address"> Home Address <span>*</span> </label>
                                    <input type="text" class="form-control" name="address" id="address"
                                        placeholder="Home Address" value="<?php echo e(old('address')); ?>" />


                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="form-row">

                                <div class="form-group col-lg-4 col-md-5 col-sm-5">
                                    <label for="gender">GENDER:<span>*</span></label>
                                    <select id="gender" name="gender">
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="others">Others</option>
                                    </select>

                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div>

                                
                                <div class="form-group col-lg-8 col-md-7 col-sm-7">

                                    <label for="birthday">Date of Birth<span>*</span></label>

                                    
                                    <select class="dob" name="DoB">
                                        <option value="1">01</option>
                                        <option value="2">02</option>
                                        <option value="3">03</option>
                                        <option value="4">04</option>
                                        <option value="5">05</option>
                                        <option value="6">06</option>
                                        <option value="7">07</option>
                                        <option value="8">08</option>
                                        <option value="9">09</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                        <option value="19">19</option>
                                        <option value="20">20</option>
                                        <option value="21">21</option>
                                        <option value="22">22</option>
                                        <option value="23">23</option>
                                        <option value="24">24</option>
                                        <option value="25">25</option>
                                        <option value="26">26</option>
                                        <option value="27">27</option>
                                        <option value="28">28</option>
                                        <option value="29">29</option>
                                        <option value="30">30</option>
                                        <option value="31">31</option>
                                    </select>

                                    
                                    <select class="dob" name="MoB">
                                        <option value="Jan">Jan</option>
                                        <option value="Feb">Feb</option>
                                        <option value="Mar">Mar</option>
                                        <option value="Apr">Apr</option>
                                        <option value="May">May</option>
                                        <option value="Jun">Jun</option>
                                        <option value="Jul">Jul</option>
                                        <option value="Aug">Aug</option>
                                        <option value="Sep">Sep</option>
                                        <option value="Oct">Oct</option>
                                        <option value="Nov">Nov</option>
                                        <option value="Dec">Dec</option>
                                    </select>

                                    
                                    <input class="year" type="number" name="year" id="year"
                                        value="<?php echo e(old('year')); ?> placeholder=" year" required>

                                    <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>


                            
                            <div class="form-row">

                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="kin"> Next of Kin </label>
                                    <input type="text" class="form-control" name="kin" id="kin"
                                        placeholder="Name of next of kin" value="<?php echo e(old('kin')); ?>" />

                                    <?php $__errorArgs = ['kin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-sm-6">
                                    <label for="kin_phone">Phone</label>
                                    <input type="tel" class="form-control" id="kin_phone" name="kin_phone"
                                        placeholder="Next of Kin's Phone" p="[0-9]{3}[0-9]{3}[0-9]{4}[0-9]{3}"
                                        value="<?php echo e(old('kin_phone')); ?>">

                                    <?php $__errorArgs = ['kin_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="form-row">
                                <div class="col-lg-12">
                                    <input type="radio" id="regular" name="confirm" value="confirmed">
                                    <label>I hereby declare that all information disclosed are correct and
                                        valid.</label>

                                    <?php $__errorArgs = ['confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <small><?php echo e($message); ?></small></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            <p> <small>* fields are required</small></p>

                            
                            <div class="text-center my-3">
                                <button type="submit" title="Send Message">
                                    Register
                                </button>

                                
                                <input class="mx-3" type="reset" value="Clear">
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/forms/forms.blade.php ENDPATH**/ ?>