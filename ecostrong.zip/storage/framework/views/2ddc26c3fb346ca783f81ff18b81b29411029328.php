<h2>Hello User,</h2>
Email received from: <?php echo e($name); ?>


User information:

Name: <?php echo e($name); ?>

Email: <?php echo e($email); ?>

Phone: <?php echo e($phone); ?>

Subject: <?php echo e($subject); ?>

Message: <?php echo e($message); ?>


Thank you<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\ecostrong\resources\views/email.blade.php ENDPATH**/ ?>