

<?php $__env->startSection('content'); ?>


    
    <div id="hero">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 hero-text">
                    <h1 data-aos="slide-left" data-aos-duration="200">
                        INVEST. SELL. BUY. BUILD. CONSULT
                    </h1>
                    <p data-aos="slide-right" data-aos-duration="400"> Wide range of properties and business opportunities
                        to explore at <span>Ecostrong</span>. We are
                        committed to service with integrity.
                    </p>


                    <div data-aos="fade-up" data-aos-duration="500" data-aos-delay="500">
                        <a href="<?php echo e(url('/contact_us')); ?>"> <button class="btn pry"> Contact Us</button> </a>
                        <a href="<?php echo e(url('/properties')); ?>"> <button class="btn sec">View Properties</button> </a>
                    </div>
                </div>
                <div data-aos="fade-up" data-aos-duration="500" data-aos-delay="500" class="col-lg-6 hero-img">
                    <img class="img-fluid" src="img/hero-img.png" alt="">
                </div>
            </div>
        </div>
    </div>
    


    <main id="main">
        <!-- ========== About Us Section ========== -->
        <section class="about">
            <div class="container">
                <div class="section-title">
                    <h2>About Us</h2>
                </div>

                <div class="row content">
                    <div class="col-lg-12 text-center"" data-aos=" fade-up" data-aos-duration="500">
                        <p>
                            Ecostrong Company Limited is a Nigerian multinational commercial
                            company, that offers real estate/properties management,
                            investment, general trading, agency, project management,
                            business and management consulting services to individuals,
                            households, businesses, private and public institutions across
                            Africa and the globe with a broad range of market products and
                            services.
                        </p>
                        <a href="<?php echo e(url('/about_us')); ?>"> <button class="mybtn-2 m-2">Read More</button> </a>
                    </div>
                </div>
            </div>
        </section>
        <!-- ========== About Us Section ========== -->

        <!-- ========== Services Section ========== -->
        <section id="services">
            <div class="container" data-aos="fade-up">
                <div class="section-title" data-aos="fade-up" data-aos-duration="500">
                    <h2>Services</h2>
                    <p>
                        Our wide range of services includes the following;
                    </p>
                </div>

                <div class="row mt-4 mb-4">

                    
                    <div class="col-lg-4 col-md-6 mt-3 mb-3" data-aos="zoom-in" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon">
                                <img loading="lazy" src="img/services/real-estate.svg"
                                    alt="real-estate-and-properties-management" />
                            </div>
                            <div class="services-text">
                                <h4 class="text-center mt-4">
                                    Real Estate & Properties Management
                                </h4>
                                <hr>
                                <p>
                                    The best Investment you could ever venture into is real
                                    estate. We proffer solution in land properties and houses at
                                    affordable prices. At Ecostrong we sell, buy and also find
                                    buyers for land, buildings, gardens, farm land and
                                    properties...
                                </p>
                            </div>
                            <a href="<?php echo e(url('/services/Real Estate & Properties Management')); ?>"> <button
                                    class="mybtn-2">Read More</button></a>
                            <a href="<?php echo e(url('/properties')); ?>"><button class=" mybtn-1">Our Properties</button></a>
                        </div>

                    </div>

                    
                    <div class="col-lg-4 col-md-6 mt-3 mb-3" data-aos="zoom-in" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon">
                                <img loading="lazy" src="img/services/business consultancy.svg"
                                    alt="business-management-and-consultancy" />
                            </div>
                            <div class="services-text">
                                <h4 class="text-center mt-4">
                                    Business Management & Consultancy
                                </h4>
                                <hr>
                                <p>
                                    Learn To Build Profitable Brands, Not Just Good Looks Do you
                                    have an idea and you don’t know the How or you are looking
                                    for a better way to monetize your business? Then you are at
                                    the right place...</p>
                            </div>
                            <a href="<?php echo e(url('/services/Business Management & Consultancy')); ?>"><button
                                    class="mybtn-2">Read More</button></a>
                            <a href="<?php echo e(url('/forms/Business Management & Consultancy')); ?>"><button class="mybtn-1">Sign
                                    Up</button></a>
                        </div>
                    </div>

                    
                    <div class="col-lg-4 col-md-6 mt-3 mb-3" data-aos="zoom-in" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon">
                                <img loading="lazy" src="img/services/ecovest.svg" alt="forex investment and training" />
                            </div>
                            <div class="services-text">
                                <h4 class="text-center mt-4">
                                    Ecovest Investment & Training
                                </h4>
                                <hr>
                                <p>
                                    The biggest risk of all is not taking an investment risk.
                                    ‘Ecovest Investment Scheme” where we grow your funds within
                                    a stipulated amount of days of at least 20 working days with
                                    a Rate of interest of 20%...
                                </p>
                            </div>
                            <a href="<?php echo e(url('/services/Ecovest Investment & Training')); ?>"><button class="mybtn-2">Read
                                    More</button></a>
                            <a href="<?php echo e(url('/forms/Ecovest Investment & Training')); ?>"><button class="mybtn-1">Sign
                                    Up</button></a>
                        </div>
                    </div>

                    
                    <div class="col-lg-4 col-md-6 mt-3 mb-3" data-aos="zoom-in" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon">
                                <img loading="lazy" src="img/services/pins.svg" alt="project-investment-scheme" />
                            </div>
                            <div class="services-text">
                                <h4 class="text-center mt-4">
                                    PROJECT INVESTMENT SCHEME (PINS)
                                </h4>
                                <hr>
                                <p>
                                    Why borrow to own your project dream? With just at least 30%
                                    of your Project Budget, within a stipulated amount of days
                                    you would get the exact fund needed to execute your project
                                    effortlessly...
                                </p>
                            </div>
                            <a href="<?php echo e(url('/services/Project Investment Scheme')); ?>"><button class="mybtn-2">Read
                                    More</button></a>
                            <a href="<?php echo e(url('/forms/Project Investment Scheme')); ?>"><button class="mybtn-1">Sign
                                    Up</button></a>

                        </div>
                    </div>

                    
                    <div class="col-lg-4 col-md-6 mt-3 mb-3" data-aos="zoom-in" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon">
                                <img loading="lazy" src="img/services/project management.svg" alt="project-management" />
                            </div>
                            <div class="services-text">
                                <h4 class="text-center mt-4">Project Management</h4>
                                <hr>
                                <p>
                                    We offer project management service to both individuals and
                                    institutions, where we oversee the end-to-end administration
                                    of their projects effectively and efficiently...
                                </p>
                            </div>
                            <a href="<?php echo e(url('/services/Project Management')); ?>"><button class="mybtn-2">Read
                                    More</button></a>
                            <a href="<?php echo e(url('/forms/Project Management')); ?>"> <button class="mybtn-1">Sign
                                    Up</button></a>
                        </div>

                    </div>

                    
                    <div class="col-lg-4 col-md-6 mt-3 mb-3" data-aos="zoom-in" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon">
                                <img loading="lazy" src="img/services/general trading and contract.svg"
                                    alt="general-trading-and-contract" />
                            </div>
                            <div class="services-text">
                                <h4 class="text-center mt-4">General Trading & Contract</h4>

                                <hr>
                                <p>
                                    At Ecostrong Company, we can be hired by client based on contract to design, analyze,
                                    process, develop and execute information, ideas, products, services or projects. We help
                                    to monitor and supervise any tasks contracted to us effectively and efficiently...
                                </p>
                            </div>
                            <a href="<?php echo e(url('/services/General Trading & Contract')); ?>"><button class="mybtn-2">Read
                                    More</button></a>
                            <a href="<?php echo e(url('/forms/General Trading & Contract')); ?>"><button class="mybtn-1">Sign
                                    Up</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ========== Services Section ========== -->


        <!-- =========== Call To Action Section =========== -->
        <section id="call-to-action" class="wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 text-center text-lg-left">
                        <h3 class="cta-title">Get in Touch</h3>
                        <p class="cta-text">
                            Do you have any question(s) about our services, pricing, general enquiries about the company, or
                            anything else? Please do well to get in touch with us and our expert support team will respond
                            swiftly.
                        </p>
                    </div>
                    <div class="col-lg-3 cta-btn-container text-center">
                        <a href="<?php echo e(url('/contact_us')); ?>"><button class="mybtn-2">Contact Us</button></a>
                    </div>
                </div>

            </div>
        </section>
        <!-- ========== End Call To Action Section ========== -->


        <!-- ======= Testimonials Section ======= -->
        <section id="testimonials">
            <div class="container">
                <div class="section-header">
                    <h2>Testimonials</h2>
                    <p>Sed tamen tempor magna labore dolore dolor sint tempor duis magna elit veniam aliqua esse amet veniam
                        enim export quid quid veniam aliqua eram noster malis nulla duis fugiat culpa esse aute nulla ipsum
                        velit export irure minim illum fore</p>
                </div>
                <div class="owl-carousel testimonials-carousel">

                    <div class="testimonial-item">
                        <p>
                            <img src="assets/img/quote-sign-left.png" class="quote-sign-left" alt="">
                            Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus.
                            Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                            <img src="assets/img/quote-sign-right.png" class="quote-sign-right" alt="">
                        </p>
                        <img src="assets/img/testimonial-1.jpg" class="testimonial-img" alt="">
                        <h3>Saul Goodman</h3>
                        <h4>Ceo &amp; Founder</h4>
                    </div>

                    <div class="testimonial-item">
                        <p>
                            <img src="assets/img/quote-sign-left.png" class="quote-sign-left" alt="">
                            Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram
                            malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                            <img src="assets/img/quote-sign-right.png" class="quote-sign-right" alt="">
                        </p>
                        <img src="assets/img/testimonial-2.jpg" class="testimonial-img" alt="">
                        <h3>Sara Wilsson</h3>
                        <h4>Designer</h4>
                    </div>

                    <div class="testimonial-item">
                        <p>
                            <img src="assets/img/quote-sign-left.png" class="quote-sign-left" alt="">
                            Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis
                            minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                            <img src="assets/img/quote-sign-right.png" class="quote-sign-right" alt="">
                        </p>
                        <img src="assets/img/testimonial-3.jpg" class="testimonial-img" alt="">
                        <h3>Jena Karlis</h3>
                        <h4>Store Owner</h4>
                    </div>

                    <div class="testimonial-item">
                        <p>
                            <img src="assets/img/quote-sign-left.png" class="quote-sign-left" alt="">
                            Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim
                            velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum
                            veniam.
                            <img src="assets/img/quote-sign-right.png" class="quote-sign-right" alt="">
                        </p>
                        <img src="assets/img/testimonial-4.jpg" class="testimonial-img" alt="">
                        <h3>Matt Brandon</h3>
                        <h4>Freelancer</h4>
                    </div>

                    <div class="testimonial-item">
                        <p>
                            <img src="assets/img/quote-sign-left.png" class="quote-sign-left" alt="">
                            Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim
                            culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum
                            quid.
                            <img src="assets/img/quote-sign-right.png" class="quote-sign-right" alt="">
                        </p>
                        <img src="assets/img/testimonial-5.jpg" class="testimonial-img" alt="">
                        <h3>John Larson</h3>
                        <h4>Entrepreneur</h4>
                    </div>

                </div>

            </div>
        </section><!-- End Testimonials Section -->

       



    </main>
    <!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abiod\Desktop\Web Development\PHP-Projects\ecostrong\resources\views/index.blade.php ENDPATH**/ ?>