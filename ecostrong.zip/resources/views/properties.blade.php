@extends("layouts.app")

@section('content')
    @include('layouts.inner_header')

    @include('layouts.property_temp')

    @include('layouts.cta')


@endsection
