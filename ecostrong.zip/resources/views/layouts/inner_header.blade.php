<div id="inner-page">
    <div class="container">
        <div class="top-bar">
            <h4> <a href="{{ url('/') }}"> Home </a> | {{ $innertitle }} </h4>
        </div>
    </div>
</div>
